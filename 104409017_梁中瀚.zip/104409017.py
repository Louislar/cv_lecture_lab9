import cv2
import numpy as np 


# read mask and image
mask = cv2.imread("mask.jpg")
image = cv2.imread("test.jpg")
crop_img = image
# RGBtoHSV
mask_hsv = cv2.cvtColor(mask, cv2.COLOR_BGR2HSV)

# Find blue color to binary
lower_blue = np.array([110,50,50])
upper_blue = np.array([130,255,255])
mask_thresh = cv2.inRange(mask_hsv, lower_blue, upper_blue)

# Filter RGB image
res = cv2.bitwise_and(image,image, mask= mask_thresh)

# mask rcnn return boxes' points
y1, x1, y2, x2 = (62, 313, 647, 987)
width = x2-x1
height = y2-y1

# crop image
res = res[y1:y1+height, x1:x1+width]

# save and show
cv2.imwrite("target.jpg", res)
cv2.imshow("image", res)
cv2.waitKey(0)